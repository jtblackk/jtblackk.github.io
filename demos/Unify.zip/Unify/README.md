# Unify
Unify shares system outputs and inputs. It essentially lets you use your laptop and desktop as if they are displays hooked to the same computer.

At the moment, it is limited to sharing audio. 

Instructions and executable to come.

Roadmap:
1. develop basic ui
2. implement audio sharing
3. implement keyboard/mouse sharing
4. implement webcam sharing
5. polish ui/ux

Motivation for the project: I find myself in situations where I'm using my laptop and desktop at the same time. I would like to be able to link them together so I can share a single keyboard, mouse, and set of audio equipment.
